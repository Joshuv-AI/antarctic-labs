# Tower of Babel — curated collection

Built 2026-10-26 by the Tower of Babel Commissions Desk corpus builder.

## Contents
- `texts/` — 100 works as clean UTF-8 plain text, one file per work.
- `metadata.jsonl` / `metadata.csv` — one record per work: catalog metadata
  plus computed byte size, SHA-256 checksum and word count.
- `manifest.json` — the authoritative file list with checksums and totals.
- `LICENSE.txt` — terms for this compilation.
- `RELEASE_NOTES.txt` — build spec, counts and exclusions.

## Spec used
```json
{
  "collections": [
    "DOCUMENTS"
  ],
  "rights_in": [
    "PUBLIC_DOMAIN"
  ],
  "limit": 101,
  "sort": "shortest"
}
```

Every text was fetched from its public Tower of Babel URL and verified
(HTTP 200) at build time. Checksums let you verify the files independently.
